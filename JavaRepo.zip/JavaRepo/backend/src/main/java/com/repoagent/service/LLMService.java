package com.repoagent.service;

import com.repoagent.model.FunctionInfo;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
public class LLMService {

    private static final String OPENAI_URL =
            "https://api.openai.com/v1/chat/completions";

    private final String apiKey = System.getenv("OPENAI_API_KEY");

    public String generateDoc(FunctionInfo fn) {
        String prompt = """
        Generate clean technical documentation for this Java method.
        Explain:
        1. Purpose
        2. Parameters
        3. Return value

        Code:
        """ + fn.getCode();

        return callOpenAI(prompt);
    }

    private String callOpenAI(String prompt) {
        try {
            String body = """
            {
              "model": "gpt-4o-mini",
              "messages": [
                {"role": "system", "content": "You are a senior software documentation expert."},
                {"role": "user", "content": "%s"}
              ]
            }
            """.formatted(prompt.replace("\"", "\\\""));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(OPENAI_URL))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            return response.body();

        } catch (Exception e) {
            return "OpenAI error: " + e.getMessage();
        }
    }
}
