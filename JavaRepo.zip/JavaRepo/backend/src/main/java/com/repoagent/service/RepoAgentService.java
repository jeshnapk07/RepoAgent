package com.repoagent.service;

import com.repoagent.model.FunctionInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Service
public class RepoAgentService {

    @Autowired GitService git;
    @Autowired ParserService parser;
    @Autowired LLMService llm;
    @Autowired DocumentationService docs;

    public List<String> run() {
        List<String> generated = new ArrayList<>();

        for (File file : git.getChangedFiles()) {
            for (FunctionInfo fn : parser.extractFunctions(file)) {
                String doc = llm.generateDoc(fn);
                docs.save(fn, doc);
                generated.add(fn.getName());
            }
        }
        return generated;
    }
}
