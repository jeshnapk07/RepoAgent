package com.repoagent.service;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.repoagent.model.FunctionInfo;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Service
public class ParserService {

    public List<FunctionInfo> extractFunctions(File file) {
        List<FunctionInfo> list = new ArrayList<>();
        try {
            var cu = StaticJavaParser.parse(file);
            for (MethodDeclaration m : cu.findAll(MethodDeclaration.class)) {
                list.add(new FunctionInfo(
                        m.getNameAsString(),
                        m.toString()
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }
}
