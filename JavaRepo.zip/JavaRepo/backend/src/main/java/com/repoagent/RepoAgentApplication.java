package com.repoagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepoAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(RepoAgentApplication.class, args);
    }
}
