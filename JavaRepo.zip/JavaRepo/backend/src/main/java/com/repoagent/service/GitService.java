package com.repoagent.service;

import org.springframework.stereotype.Service;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Service
public class GitService {

    public List<File> getChangedFiles() {
        List<File> files = new ArrayList<>();
        scan(new File("src/main/java"), files);
        return files;
    }

    private void scan(File dir, List<File> files) {
        File[] list = dir.listFiles();
        if (list == null) return;

        for (File f : list) {
            if (f.isDirectory()) scan(f, files);
            else if (f.getName().endsWith(".java")) files.add(f);
        }
    }
}
