package com.repoagent.service;

import com.repoagent.model.FunctionInfo;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;

@Service
public class DocumentationService {

    public void save(FunctionInfo fn, String doc) {
        try {
            File dir = new File("docs");
            if (!dir.exists()) dir.mkdir();

            FileWriter w = new FileWriter("docs/" + fn.getName() + ".md");
            w.write("## " + fn.getName() + "\n\n" + doc);
            w.close();
        } catch (Exception ignored) {}
    }
}
