package com.repoagent.controller;

import com.repoagent.service.RepoAgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class RepoAgentController {

    @Autowired RepoAgentService service;

    @PostMapping("/run")
    public List<String> run() {
        return service.run();
    }
}
