export async function runAgent() {
  const res = await fetch("http://localhost:8080/api/run", {
    method: "POST"
  });
  return res.json();
}
