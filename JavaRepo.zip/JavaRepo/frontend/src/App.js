import RunAgent from "./components/RunAgent";

function App() {
  return (
    <div>
      <h1>RepoAgent</h1>
      <RunAgent />
    </div>
  );
}

export default App;