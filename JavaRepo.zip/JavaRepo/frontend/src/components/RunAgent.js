import { runAgent } from "../api";

export default function RunAgent() {
  const run = async () => {
    const data = await runAgent();
    alert("Docs generated for: " + data.join(", "));
  };

  return <button onClick={run}>Run RepoAgent</button>;
}
